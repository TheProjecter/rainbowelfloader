/* CYGNUS LOCAL mcore/entire file.  */
/* Define __gnuc_va_list. */

#ifndef __GNUC_VA_LIST
#define __GNUC_VA_LIST
typedef void * __gnuc_va_list;
#endif /* not __GNUC_VA_LIST */

/* If this is for internal libc use, don't define anything but
   __gnuc_va_list.  */
#if defined (_STDARG_H) || defined (_VARARGS_H)

#ifdef _STDARG_H
#define va_start(AP, LASTARG)						\
  (AP = ((__gnuc_va_list) __builtin_next_arg (LASTARG)))
#else
#define __va_ellipsis  ...
#define va_alist       __builtin_va_alist
#define va_dcl         int __builtin_va_alist; __va_ellipsis
#define va_start(AP)   AP = (char *) & __builtin_va_alist
#endif

/* Now stuff common to both varargs & stdarg implementations.  */
#define __va_rounded_size(TYPE)						\
  (((sizeof (TYPE) + sizeof (int) - 1) / sizeof (int)) * sizeof (int))

/* assumes 8-bit aligned! */
#define __va_aligned_double(AP,TYPE) \
     (sizeof (TYPE) + (((int)AP & 4) ? sizeof (int) : 0))

#define __va_rounded_small(TYPE) sizeof (TYPE)
#ifdef __MCOREL__
#undef  __va_rounded_small
#define __va_rounded_small(TYPE) __va_rounded_size (TYPE)
#endif
     
#undef va_end
     
void va_end (__gnuc_va_list);

#define va_end(AP) ((void)0)

/* We need to be able to detect structures and handle them specially.  */
#define __va_aggregate_p(TYPE)	(__builtin_classify_type(*(TYPE *)0) >= 12)

#define va_arg(AP, TYPE)						\
  /* Arguments more than 8 bytes in length are passed by reference.  */	\
  ((__va_aggregate_p (TYPE) && sizeof (TYPE) > 8) ?			\
     (AP = (__gnuc_va_list) ((char *) (AP) + __va_rounded_size (char *)),\
      ** ((TYPE **) (void *)((char *) (AP) - __va_rounded_size (char *))))\
 /* Otherwise if we are using 8 byte alignment and the argument is a double  \
    or a long long then it will be passed at an 8 byte aligned address.  */    \
   : (! __va_aggregate_p (TYPE) && (sizeof (TYPE) % sizeof (double) == 0)) ?\
     (AP = (__gnuc_va_list) ((char *) (AP) + __va_aligned_double (AP,TYPE)),\
      * ((TYPE *) (void *)  ((char *) (AP) - __va_rounded_size (TYPE))))\
 /* Otherwise if they are int or double int sized are passed normally.  */\
   : (sizeof (TYPE) % sizeof (int) == 0) ?				\
     (AP = (__gnuc_va_list) ((char *) (AP) + __va_rounded_size (TYPE)),	\
      * ((TYPE *) (void *)  ((char *) (AP) - __va_rounded_size (TYPE))))\
 /* Otherwise if they are less than an int in size are placed in a word.  */\
   : (sizeof (TYPE) < 4) ?						\
     (AP = (__gnuc_va_list) ((char *) (AP) + __va_rounded_size (TYPE)),	\
      * ((TYPE *) (void *)  ((char *) (AP) - __va_rounded_small (TYPE))))\
 /* Otherwise structures of 5 - 7 bytes are passed packed into words.  */\
   : (__va_aggregate_p (TYPE) && sizeof (TYPE) < 8) ?			\
     (AP = (__gnuc_va_list) ((char *) (AP) + __va_rounded_size (TYPE)),	\
      * ((TYPE *) (void *)  ((char *) (AP) - __va_rounded_size (TYPE))))\
 /* Otherwise they are passed by reference.  */				\
   : (AP = (__gnuc_va_list) ((char *) (AP) + __va_rounded_size (char *)),\
      ** ((TYPE **) (void *)((char *) (AP) - __va_rounded_size (char *)))))

#endif /* defined (_STDARG_H) || defined (_VARARGS_H) */
